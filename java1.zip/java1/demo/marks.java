package demo;

public class marks {
	public static void main(String args[]) {
		int marks=150;
		try {
			if(marks>=500 && marks<200) {
				throw new marksrange("student is failed");
			}
		}
		catch(marksrange e) {
			System.out.println(e);
		}
	}
}
class marksrange  extends Exception{
	
	public marksrange(String message) {
		super(message);
	}
}
