package demo;

public class arrayoutoffbound {
	public static void main(String[] args) {  
	String[] arr = {"Rose","jasmine","lily","lotus"};   
	for(int i=0;i<=arr.length;i++) {       
	 System.out.println(arr[i]);      
	         }  
	  
	    } 
	}  

