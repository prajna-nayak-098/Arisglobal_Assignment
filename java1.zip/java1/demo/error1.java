package demo;

public class error1 {
	public static void main(String aa[])
    {
        try {
    String var=null;

    System.out.print(var.charAt(3));
    }

    catch(Exception e)
    {
        System.out.print(e);
    }
    }
}

