package firstproject;

public class average {
	public void avg(int a,int b,int c,int d,int e)
	{
		float avge=a+b+c+d+e/5;
		System.out.print("average of 5 number is:"+ avge);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		average a1=new average();
		a1.avg(10, 20, 10, 30, 40);
	}

}
