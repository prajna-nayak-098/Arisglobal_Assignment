package firstproject;

public class Greatest4no {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=20,c=6,d=80;
		if(a>b && a>c && a>d)
		{
			System.out.print("a is greater number");
		}
		else if(b>a && b>c && b>d)
		{
			System.out.print("b is greater number");
		}
		
		else if(c>a && c>b && c>d)
		{
			System.out.print("c is greater number");
		}
		else
		{
			System.out.print("d is greater number");
		}

	}

}
