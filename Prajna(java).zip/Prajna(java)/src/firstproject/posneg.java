package firstproject;

public class posneg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=-10;
if(a>0)
{
	System.out.print(a+" is positive number");
}
else
{
	System.out.print(a+" is negative number");
}
	}

}
