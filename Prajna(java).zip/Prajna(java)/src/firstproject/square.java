package firstproject;

public class square {
public void squares(int s)
{
	int a=s*s;
	System.out.print("area of the square is:" +a);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		square s= new square();
		s.squares(10);
	}

}
