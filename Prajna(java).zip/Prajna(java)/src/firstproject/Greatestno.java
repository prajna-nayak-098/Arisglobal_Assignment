package firstproject;

public class Greatestno {
	public static void main(String args[])
	{
		int a=10,b=20,c=6;
		if(a>b && a>c)
		{
			System.out.print("a is greater number");
		}
		else if(b>a && b>c)
		{
			System.out.print("b is greater number");
		}
		
		else
		{
			System.out.print("c is greater number");
		}
	}
	

}
