package firstproject;

public class Callsbill {

	public static void main(String[] args) {
		

		int units=51,bills;
		if(units>151)
		{
			bills=(units-150)*9+50*6+50*8;
			System.out.print("units cost Rs 9 is "+bills);
		}
		else if(units>=101 && units<150)
		{
			bills=(units-100)*8+50*6;
			System.out.print("units cost Rs 8 is "+bills);
		}
		else if(units>=51 && units<100)
		{
			bills=(units-50)*6;
			
			System.out.print("units cost Rs6 is "+bills);
		}
		else
		{
			System.out.print(" First 50 units are free");
		}
	}

}
