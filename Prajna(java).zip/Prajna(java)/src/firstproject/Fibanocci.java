package firstproject;

public class Fibanocci {

	public static void main(String[] args) {
		int num=0,num1=1,num2;
		 System.out.print(num+" "+num1+" ");
		 
		for(int i=0;i<=20;i++)
		{
			num2=num1+num;
			System.out.print(" "+num2);
			num=num1;
			num1=num2;
			
		}
		}
		

}
