package firstproject;

public class Simpleintrest {
	
	public void simple(int p,int q, int r)
	{
		 float SI=p*q*r/100;
		 System.out.print("simple intrest is: "+SI);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Simpleintrest a=new Simpleintrest();
      a.simple(10, 20, 30);
	}

}
