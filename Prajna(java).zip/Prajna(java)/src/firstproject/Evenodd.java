package firstproject;

public class Evenodd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=7;
		if(a%2==0)
		{
			System.out.print(a+" is even number");
		}
		else
		{
			System.out.print(a+" is odd number");
		}

	}

}
