package firstproject;

public class rectangle {

	public void area(int w,int h)
	{
		float area=w*h;
		System.out.print("area of the rectangle is:" +area);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		rectangle r= new rectangle();
		r.area(10,20);
	}

}
