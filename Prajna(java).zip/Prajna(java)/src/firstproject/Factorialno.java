package firstproject;

public class Factorialno {

	public static void main(String[] args) {
		int a=4,fact=1;
		for(int i=1;i<=a;i++)
		{
			fact=i*fact;
			
		}
		System.out.print(fact);
	}

}
