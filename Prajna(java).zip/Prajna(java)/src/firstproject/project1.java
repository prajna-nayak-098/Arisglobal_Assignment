package firstproject;

public class project1 {
	
	public void details()
	{
	String name="smitha";
	int age=22;
	String tech="java";
	System.out.println("my name is "+name);
	System.out.println("my age is "+age);
	System.out.println("i learn a technology is "+tech);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("welcome");
		project1 p=new project1();
		p.details();
		System.out.println("-------------------------");
		System.out.println("my details is--------------");
		System.out.println("my name is smitha");
		System.out.println("my age is 22");
		System.out.println("i learn technolgy java");
	}

}
