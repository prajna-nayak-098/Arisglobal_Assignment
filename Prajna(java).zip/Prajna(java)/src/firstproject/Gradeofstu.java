package firstproject;

public class Gradeofstu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int marks=300;
		if(marks>400 && marks<600)
		{
			System.out.print("A grade");
		}
		else if(marks<=400 && marks>300)
		{
			System.out.print("B grade");
		}
		else if(marks<=300 && marks>100)
		{
			System.out.print("C grade");
		}
		else
		{
			System.out.print("D grade");
		}
	}

}
