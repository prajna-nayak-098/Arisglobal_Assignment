package firstproject;

public class Sumofnum {

	public static void main(String[] args) {
		int sum=0;
		for(int i=0;i<=100;i++)
		{
			sum=sum+i;
		}
System.out.print(sum);
	}

}
