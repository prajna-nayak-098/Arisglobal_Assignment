package prajna_methods;

public class Students {

	String name;
	int rollno;
	
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getRollno() {
		return rollno;
	}


	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
public static void main(String[] args)
{

	Students s= new Students();
	s.setName("smitha");
	System.out.println(s.getName());
	s.setRollno(1);
	System.out.println(s.getRollno());

}
}

