package prajna_methods;

public class Returntype {

	public String evenodd(int a)
	{
		if(a%2==0)
		{
		return "even number";
		}
		else
		{
			return "odd number";
		}
	}
	
	public String posneg(int b)
	{
		if(b>0)
		{
			return "Given number is positive";
		}
		else
		{
			return"negative number";
					
		}
	}
	
	public int sum(int n)
	{
		int sum=0;
		for(int i=1;i<=100;i++)
		{
			 sum=sum+i;
		}
		return sum;
	}
	
	public double areacir(int r)
	{
		double area= (3.14*r*r);
		return area;
	}
	public int arearec(int l,int b)
	{
		int area1=l*b;
		return area1;
	}
	public int areasqr(int a)
	{
		int area2=a*a;
		return area2;
	}
	public static void main(String[] args) {
		
		 Returntype r=new  Returntype ();
		System.out.println( r.evenodd(5));
		System.out.println( r.posneg(-12));
		System.out.println( r.sum(100));
		System.out.println( "area of circle is:"+r.areacir(10));
		System.out.println("area of rectangle is:"+ r.arearec(10,20));
		System.out.println("area of square is:"+ r.areasqr(30));
	}

}
