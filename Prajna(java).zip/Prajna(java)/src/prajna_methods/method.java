package prajna_methods;

import java.util.Scanner;

public class method {

	public void fact(int n)
	{
		int num=1;
		for(int i=1;i<=n;i++)
		{
			num=num*i;
		}
		System.out.println("Fcatorial of number is : "+num);
	}
	
	public void sum(float a, float b)
	{
		System.out.println("Sum is : "+(a+b));
	}
	
	public void areac(int r)
	{
		System.out.println("Area of the circle is: "+3.14*r*r);
	}
	public void arear(int l,int b)
	{
		System.out.println("Area of the rectangle is : "+l*b);
	}
	public void areas(int a)
	{
		System.out.println("area of square is: "+a*a);
	}
	
	
	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
       method m= new method();
       m.fact(5);
       m.sum(16.7f, 29.8f);
       m.arear(20,10);
       System.out.println("enter the radius");
       int area=scan.nextInt();
       m.areac(area);
       System.out.println("enter the number");
       int area1=scan.nextInt();
       m.areas(area1);
       
	}

}
