package prajna_methods;

public class Ststicmethod {

	static int i=10;
	int n=10;
	public int changevariable()
	{
		i++;
		return i;
		
	}
	public int changevariable2()
	{
		n++;
		return n;
		
	}
	public static void main(String[] args) {
		
		Ststicmethod a=new Ststicmethod();
		Ststicmethod b= new Ststicmethod();
		Ststicmethod c = new Ststicmethod();
 
        System.out.println(b.changevariable());
	    System.out.println(c.changevariable());

	    System.out.println(b.changevariable2());
	    System.out.println(c.changevariable2());

	    System.out.println("--------------------------");
			
			Students s= new Students();
			s.setName("smitha");
			System.out.println(s.getName());
			s.setRollno(1);
			System.out.println(s.getRollno());
			
		}
		
		
	}


