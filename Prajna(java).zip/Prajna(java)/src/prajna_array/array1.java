package prajna_array;

import java.util.Scanner;

public class array1 {
	    public static void main(String aa[])
	    {
	    	Scanner scan=new Scanner(System.in);
	    	System.out.println("Enter the size of the array:");
	    	int size=scan.nextInt();
	    	int arr[]= new int[size];
	    	 System.out.println("Enter the elements of array : ");
	    	for(int i=0;i<size;i++)
	    	{
	    		arr[i]=scan.nextInt();
	    	}
	    	
	    	 System.out.println("array elements are: ");
	    	 for(int i=0;i<size;i++) {
	    		 System.out.println(arr[i]);
	    	 }
	   
	}

}
