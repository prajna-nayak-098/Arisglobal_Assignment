package prajna_array;

public class array2 {
	public static void main(String args[])
    {
		int arr[]= {10,20,8,3,7,6};
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}

    }
}
