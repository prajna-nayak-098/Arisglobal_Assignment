package while_and_dowhile;

public class Factorial {

	public static void main(String[] args) {
		int a=4,fact=1 ,i=1;
		while(i<=a)
		{
			fact=i*fact;
			i++;
		}
		System.out.print(fact);

	}

}
