package while_and_dowhile;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		int add,sub,mul,div;
		
		Scanner scan= new Scanner(System.in);
		System.out.println("----------Calculator-----------");
		System.out.println("Enter the first number: ");
		int a=scan.nextInt();
		System.out.println("Enter the second number");
		int b=scan.nextInt();
		System.out.println("Select your operation: ");
		System.out.println("1. for Addition  ");
		System.out.println("2. for Subtraction  ");
		System.out.println("3. for Multiplication  ");
		System.out.println("4. for Division10 ");
		int oper=scan.nextInt();
		if(oper==1)
		{
			add=a+b;
			System.out.println("Addition"+add);
		}
		else if(oper==2)
		{
			sub=a-b;
			System.out.println("Subtraction is : "+sub);
		}
		else if(oper==3)
		{
			mul=a*b;
			System.out.println("Multiplication is : "+mul);
		}
		else if(oper==4)
		{
			div=a/b;
			System.out.println("Division is : "+div);
		}
		else
		{
			System.out.println("Enter the correct choice");
		}
		System.out.println("Do you want to continue? Y/N");
		char ch1=scan.next().charAt(0);
		while(ch1=='y' || ch1=='Y')
		{
			Scanner s= new Scanner(System.in);
			System.out.println("----------Calculator-----------");
			System.out.println("Enter the first number: ");
			int a1=s.nextInt();
			System.out.println("Enter the second number");
			int b1=s.nextInt();
			System.out.println("Select your operation: ");
			System.out.println("1. for Addition  ");
			System.out.println("2. for Subtraction  ");
			System.out.println("3. for Multiplication  ");
			System.out.println("4. for Division10 ");
			int oper1=s.nextInt();
			if(oper1==1)
			{
				add=a1+b1;
				System.out.println("Addition is "+add);
			}
			if(oper1==2)
			{
				sub=a1-b1;
				System.out.println("Subtraction is : "+sub);
			}
			if(oper1==3)
			{
				mul=a1*b1;
				System.out.println("Multiplication is : "+mul);
			}
			if(oper1==4)
			{
				div=a1/b1;
				System.out.println("Division is : "+div);
			}
			System.out.println("Do you want to continue? Y/N ");
			 ch1=s.next().charAt(0);
			
		}
			System.out.println("Thank you");
		}
	}


