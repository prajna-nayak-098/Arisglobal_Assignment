package while_and_dowhile;

public class Factorialdowhile {
	public static void main(String args[])
	{
	int a=4,fact=1,i=1;
	do
	{
		fact=i*fact;
		i++;
	}
	while(i<=a);
	System.out.print(fact);
}
}