package while_and_dowhile;

public class Tables {
	
		public static void main(String[] args) {
			int a=3,i=1,num;
			while(i<=10)
			{
				num=a*i;
				i++;
				System.out.println(num);
			}
			
		}
}
