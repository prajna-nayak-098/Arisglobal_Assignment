package while_and_dowhile;

import java.util.Scanner;

public class Order {

		public static void main(String[] args) {
			char c;
			int t=80,co=50,d=150,r=50,b=150,g=80,p=50,sum=0;
			Scanner scan = new Scanner(System.in);
			System.out.println("Order the items");
			do {
			System.out.println("1.Breakfast \n 2.Lunch \n 3.Dinner");
			int ch= scan.nextInt();
			if(ch==1)
			{
				System.out.println("Breakfast items are");
				
				System.out.println("1.Tea \n 2.Coffe \n 3.Dosha");
				int ch1= scan.nextInt();
				
				if(ch1==1)
				{
					sum=sum+t;
					System.out.println("Tea is:"+t);	
					System.out.println("Do you want to order something more y/n");
					
				}
				else if(ch1==2)
				{
					sum=sum+co;
					System.out.println("Coffe is: "+co);	
					System.out.println("Do you want to order something more y/n");
					
				}
				else if(ch1==3)
				{
					sum=sum+d;
					System.out.println("Dhosa is: "+d);	
					System.out.println("Do you want to order something more y/n");
					
				}
				
				
				
				
				
			}
			
			else if(ch==2)
			{
				System.out.println("Lunch items are");
	
				System.out.println("1.Roti \n 2.Biryani");
				int ch1= scan.nextInt();
				
				if(ch1==1)
				{
					sum=sum+r;
					System.out.println("Roti is :"+r);	
					System.out.println("Do you want to order something more y/n");
					
				}
				else if(ch1==2)
				{
					sum=sum+b;
					System.out.println("Biryani is: "+b);	
					System.out.println("Do you want to order something more y/n");
					
				}
					
				
			}
			if(ch==3)
			{
				System.out.println("Dinner items are");
			
				System.out.println("1.Gobi \n 2.puri \n ");
				int ch1= scan.nextInt();
				
				if(ch1==1)
				{
					sum=sum+g;
					System.out.println("Gobi is:"+g);	
					System.out.println("Do you want to order something more y/n");
					
				}
				else if(ch1==2)
				{
					sum=sum+p;
					System.out.println("Puri : "+p);	
					System.out.println("Do you want to order something more y/n");
					
				}
						
			}
			c=scan.next().charAt(0);
			 
			
			}while(c=='y'|| c=='Y');
			System.out.println("Thank You");
			System.out.println("Total bill is : "+sum);
			
		}

}





