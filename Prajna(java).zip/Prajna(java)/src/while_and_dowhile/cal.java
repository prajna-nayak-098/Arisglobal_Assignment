package while_and_dowhile;
import java.util.Scanner;
public class cal {
		public static void main(String[] args) {
			int add,sub,mul,div;
			char ch;
			do {
			Scanner scan= new Scanner(System.in);
			System.out.println("----------Calculator-----------");
			System.out.println("Enter the first number: ");
			int a=scan.nextInt();
			System.out.println("Enter the second number");
			int b=scan.nextInt();
			System.out.println("Select your operation: ");
			System.out.println("1. for Addition  ");
			System.out.println("2. for Subtraction  ");
			System.out.println("3. for Multiplication  ");
			System.out.println("4. for Division10 ");
			int oper=scan.nextInt();
			if(oper==1)
			{
				add=a+b;
				System.out.println("Addition"+add);
			}
			else if(oper==2)
			{
				sub=a-b;
				System.out.println("Subtraction is : "+sub);
			}
			else if(oper==3)
			{
				mul=a*b;
				System.out.println("Multiplication is : "+mul);
			}
			else if(oper==4)
			{
				div=a/b;
				System.out.println("Division is : "+div);
			}
			else
	        {
	 
	            System.out.println("Enter valid choice(1,2,3,4)");
	        }
			 System.out.println("Do you want to continue?(yes/no)");
			 ch=scan.next().charAt(0);
		        }
		        while(ch=='y'||ch=='Y');
		        System.out.println("Thankyou!!!");
		

	}

}
