package while_and_dowhile;

public class Sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int sum=0,i=0;
		do{
			sum=sum+i;
			i++;
		}while(i<=100);
		
       System.out.print(sum);

	}

}
