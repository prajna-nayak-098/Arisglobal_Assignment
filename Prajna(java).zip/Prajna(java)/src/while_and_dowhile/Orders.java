package while_and_dowhile;

import java.util.Scanner;

public class Orders {

	public static void main(String[] args) {
		char c;
		Scanner scan = new Scanner(System.in);
		System.out.println("Order the items");
		System.out.println("1.Breakfast \n 2.Lunch \n 3.Dinner");
		int ch= scan.nextInt();
		if(ch==1)
		{
			System.out.println("Breakfast items are");
			do {
			System.out.println("1.Tea \n 2.Coffe \n 3.Dosha");
			int ch1= scan.nextInt();
			
			if(ch1==1)
			{
				System.out.println("Tea 80/-");	
				System.out.println("Do you want to order something more y/n");
				
			}
			else if(ch1==2)
			{
				System.out.println("Coffe 50/-");	
				System.out.println("Do you want to order something more y/n");
				
			}
			else if(ch1==3)
			{
				System.out.println("Dhosa 150/-");	
				System.out.println("Do you want to order something more y/n");
				
			}
			
			 c=scan.next().charAt(0);
			}while(c=='y'|| c=='Y');
			
			
			System.out.println("Thank You");
			
		}
		
		else if(ch==2)
		{
			System.out.println("Lunch items are");
			do {
			System.out.println("1.Roti \n 2.Biryani");
			int ch1= scan.nextInt();
			
			if(ch1==1)
			{
				System.out.println("Roti 50/-");	
				System.out.println("Do you want to order something more y/n");
				
			}
			else if(ch1==2)
			{
				System.out.println("Biryani 150/-");	
				System.out.println("Do you want to order something more y/n");
				
			}
			
			 c=scan.next().charAt(0);
			}while(c=='y'|| c=='Y');
			
			System.out.println("Thank You");
			
		}
		if(ch==3)
		{
			System.out.println("Dinner items are");
			do {
			System.out.println("1.Gobi \n 2.puri \n ");
			int ch1= scan.nextInt();
			
			if(ch1==1)
			{
				System.out.println("Gobi 80/-");	
				System.out.println("Do you want to order something more y/n");
				
			}
			else if(ch1==2)
			{
				System.out.println("Puri 50/-");	
				System.out.println("Do you want to order something more y/n");
				
			}
			
			 c=scan.next().charAt(0);
			}while(c=='y'|| c=='Y');
			
			System.out.println("Thank You");
			
		}
		
		
	}

}
