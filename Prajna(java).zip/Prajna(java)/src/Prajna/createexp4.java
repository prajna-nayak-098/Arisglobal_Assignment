package Prajna;

public class createexp4 {

		 public static void main(String args[]) 
		    {

		        int num=5;
		        try{
		         if(num%2!=0)
		         {
		             throw new even("number is not even exception");
		         }
		        }
		                 catch(even n)
		                 {
		                	 
		                    System.out.println(n); 
		                 }
		    }
		}
		class even extends Exception
		{
		 
		    public even(String message) {
		        super(message);

		    }
		}


