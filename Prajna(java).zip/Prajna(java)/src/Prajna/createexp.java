package Prajna;

public class createexp {
	
	    public static void main(String args[]) 
	    {

	        int marks=130;
	        try{
	         if(marks<200)
	         {
	             throw new marks("student failed exception");
	         }
	        }
	                 catch(marks n)
	                 {
	                	 
	                    System.out.println(n); 
	                 }
	    }
	}
	class marks extends Exception
	{
	 
	    public marks(String message) {
	        super(message);

	    }
	}
	
	
	    


