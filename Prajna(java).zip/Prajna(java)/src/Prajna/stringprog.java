package Prajna;

public class stringprog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str=null;
		int ch1='a';
		int a=10;
		try
		{
			System.out.println(ch1);
			System.out.println(str.charAt(0));
			System.out.println(a);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		}

	}