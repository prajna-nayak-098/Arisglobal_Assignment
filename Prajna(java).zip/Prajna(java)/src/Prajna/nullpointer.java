package Prajna;

public class nullpointer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str=null;
		try {
        System.out.println(str.charAt(2));

	}
		catch(NullPointerException e)
		{
			System.out.println(e);
		}
	}

}
