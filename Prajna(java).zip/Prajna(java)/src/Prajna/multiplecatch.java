package Prajna;

import java.util.InputMismatchException;
import java.util.Scanner;

public class multiplecatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		int a[]=new int[6];
		try
		{
			Scanner s=new Scanner(System.in);
			System.out.println("enter the index value");
			int b=a[s.nextInt()];
			System.out.println("enter the value of numerator and denominator:");	
		b=s.nextInt()/s.nextInt(); 
		System.out.println(b);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);	
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		catch(InputMismatchException e)
		{
			System.out.println(e);
		}
	}

}
