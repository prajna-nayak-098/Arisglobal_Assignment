package Constructor;

class Homepage {
	Homepage()
	{
		loginpage p=new loginpage(10,"smitha");
		 System.out.println("welcome "+p.name);
		
	}

	public static void main(String[] args) {
		 Homepage h= new Homepage();
		

	}

}