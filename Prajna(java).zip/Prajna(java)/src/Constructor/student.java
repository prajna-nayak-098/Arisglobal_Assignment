//package Constructor;
//
//public class student {
//	String name;
//
//	student(String name)
//	{
//		this.name=name;
//	}
//	student()
//	{
//		name="unknown";
//	}
//	
//	public static void main(String[] args) {
//		student s = new student("smitha");
//		System.out.println(s.name);
//		student s1 = new student();
//		System.out.println(s1.name);
//		
//
//	}
//
//}
