package Constructor;

public class triangle {

	triangle()
	{
		int a=3;
		int b=4;
		int c=5;
		int peri=a+b+c;
		System.out.println("perimeter of a triangle is: "+peri);
		double area=0.5*b*a;
		System.out.println("Area of the triangle is :"+area);
	}
	public static void main(String[] args) {
		
		triangle t1 = new triangle();

	}

}
