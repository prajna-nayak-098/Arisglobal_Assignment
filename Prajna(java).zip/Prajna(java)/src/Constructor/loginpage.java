package Constructor;

public class loginpage {

	int id;
	String name;
	
	loginpage(int rollno,String name1)
	{
		id=rollno;
		name=name1;

		System.out.println(rollno+ " "+ name1);
	}

}


