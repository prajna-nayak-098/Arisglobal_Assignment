package prajna_Interface;
	interface Ivehicle {
		public double tuneUpCost();
	    public boolean canCarry(int numPassengers);
	}

