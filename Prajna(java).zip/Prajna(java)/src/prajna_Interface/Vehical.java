package prajna_Interface;
//interface IVehicle {
//	public double tuneUpCost();
//    public boolean canCarry(int numPassengers);
//}

public class Vehical implements Ivehicle
{
	public double tuneUpCost()
	{
		int carrymillage=10000;
		double noofyears=1.5;
		double tuneup;
//		return tuneup;
		
		if(noofyears<=1)
		{
			
			tuneup=carrymillage*noofyears;
		}
		else if(noofyears<3 && noofyears>1)
		{
			tuneup=carrymillage*noofyears;
		}
		else
		{
			tuneup=carrymillage*noofyears;
		}
		return tuneup;
	}
    public boolean canCarry(int numPassengers)
    {
    	if(numPassengers<=5)
    	{
    		return true;
    	}
    	else
    	{
    		
    	}
    	return false;
    }
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Vehical v = new  Vehical();
//		System.out.println( v.canCarry(10));
		 System.out.println("tuneup cost is: "+v.tuneUpCost());
		System.out.println("vehicle can hold given num of passengers: "+ v.canCarry(4));
		 
	}

}
