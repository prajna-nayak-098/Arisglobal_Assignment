package prajna_Interface;
/*Write a program to create interface A in this
interface we have two method meth1 and meth2.
Implements this interface in another class named MyClass*/
interface A
{
	void meth1();
	void meth2();
}

public class MyClass implements A
{
	public void meth1()
	{
		System.out.println("Method one");
	}
	public void meth2()
	{
		System.out.println("Method two");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClass m= new MyClass();
		m.meth1();
		m.meth2();
				

	}

}
