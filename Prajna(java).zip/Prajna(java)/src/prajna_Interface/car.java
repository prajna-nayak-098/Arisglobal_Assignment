package prajna_Interface;

abstract class MotorBike {
	  abstract void brake();
	}

class bike extends MotorBike
{
	public void brake()
	{
		System.out.println("bike having a brake");
	}
}
public class car extends MotorBike
{
	public void brake()
	{
		System.out.println("car having a brake");
	}

	public static void main(String[] args) {
		bike b= new bike();
		b.brake();
		car c= new car();
		c.brake();

	}

}
