package prajna_Interface;

abstract class Animal {
	  abstract  void makeSound();
	  public void eat() {
	   //add code
		  System.out.println("Every animal can eat a food");

	  }
	}

 class cat extends Animal
{
	public void makeSound()
	{
		System.out.println("The cat says: meow meow");
	}
}



public class dog extends Animal
{
	public void makeSound()
	{
		System.out.println("The dog says: bow bow");
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		dog d= new dog();
		d.eat();
		d.makeSound();
		cat c= new cat();
		c.makeSound();
		
	}

}
